#!/bin/sh
# RosetteOS Tailscale daemon service runner

STATE_DIR="/usr/data/rosetteos/tailscale"
CACHE_DIR="/usr/data/rosetteos/tailscale/.cache"
RUN_DIR="/var/run/tailscale"
LOG_DIR="/var/log"
BIN_DIR="/usr/data/rosetteos/bin"

mkdir -p "$STATE_DIR"
mkdir -p "$CACHE_DIR"
mkdir -p "$RUN_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$BIN_DIR"

# Export writable HOME and XDG_CACHE_HOME so tailscaled does not attempt
# to write logpolicy cache files to the read-only rootfs (/.cache)
export HOME="$STATE_DIR"
export XDG_CACHE_HOME="$CACHE_DIR"

# Ensure CLI symlinks exist in user PATH
[ -e "$BIN_DIR/tailscale" ] || ln -sf /usr/data/rosetteos/apps/tailscale/tailscale "$BIN_DIR/tailscale"
[ -e "$BIN_DIR/tailscaled" ] || ln -sf /usr/data/rosetteos/apps/tailscale/tailscaled "$BIN_DIR/tailscaled"

# Symlink default socket location
ln -sf "$RUN_DIR/tailscaled.sock" /var/run/tailscale.sock 2>/dev/null || true

# Verify whether kernel actually has CONFIG_TUN driver support, not just a /dev/net/tun node.
# In userspace-networking mode, Tailscale terminates all incoming TCP connections (ports 80, 7125, 22, etc.)
# directly in userspace and forwards them to localhost without requiring kernel TUN or iptables.
has_kernel_tun() {
    # Ensure device node exists to test opening it
    if [ ! -c /dev/net/tun ] && [ ! -c /dev/tun ]; then
        mkdir -p /dev/net 2>/dev/null || true
        mknod /dev/net/tun c 10 200 2>/dev/null || true
    fi
    modprobe tun 2>/dev/null || true
    # Check if kernel driver is bound to misc 10:200 or opened cleanly
    if [ -d /sys/class/misc/tun ] || grep -q '[[:space:]]tun$' /proc/misc 2>/dev/null; then
        return 0
    fi
    return 1
}

TUN_ARG="--tun=userspace-networking"
if has_kernel_tun && command -v iptables >/dev/null 2>&1; then
    TUN_ARG=""
fi

# Load optional custom flags from environment file if present
EXTRA_ARGS=""
if [ -f "/usr/data/printer_data/config/tailscale.env" ]; then
    . "/usr/data/printer_data/config/tailscale.env"
elif [ -f "/opt/printer_data/config/tailscale.env" ]; then
    . "/opt/printer_data/config/tailscale.env"
fi

exec /usr/data/rosetteos/apps/tailscale/tailscaled \
    --state="$STATE_DIR/tailscaled.state" \
    --statedir="$STATE_DIR" \
    --socket="$RUN_DIR/tailscaled.sock" \
    --port=41641 \
    $TUN_ARG \
    $EXTRA_ARGS
