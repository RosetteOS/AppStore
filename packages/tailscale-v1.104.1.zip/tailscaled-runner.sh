#!/bin/sh
# RosetteOS Tailscale daemon service runner

STATE_DIR="/usr/data/rosetteos/tailscale"
RUN_DIR="/var/run/tailscale"
LOG_DIR="/var/log"
BIN_DIR="/usr/data/rosetteos/bin"

mkdir -p "$STATE_DIR"
mkdir -p "$RUN_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$BIN_DIR"

# Ensure CLI symlinks exist in user PATH
[ -e "$BIN_DIR/tailscale" ] || ln -sf /usr/data/rosetteos/apps/tailscale/tailscale "$BIN_DIR/tailscale"
[ -e "$BIN_DIR/tailscaled" ] || ln -sf /usr/data/rosetteos/apps/tailscale/tailscaled "$BIN_DIR/tailscaled"

# Symlink default socket location
ln -sf "$RUN_DIR/tailscaled.sock" /var/run/tailscale.sock 2>/dev/null || true

# Check for TUN device support; fallback to userspace networking if unavailable
TUN_ARG=""
if [ -e /dev/net/tun ] || [ -e /dev/tun ]; then
    TUN_ARG=""
else
    mkdir -p /dev/net
    mknod /dev/net/tun c 10 200 2>/dev/null || true
    if [ ! -e /dev/net/tun ]; then
        TUN_ARG="--tun=userspace-networking"
    fi
fi

# Load optional custom flags from environment file if present
EXTRA_ARGS=""
if [ -f "/opt/printer_data/config/tailscale.env" ]; then
    . "/opt/printer_data/config/tailscale.env"
fi

exec /usr/data/rosetteos/apps/tailscale/tailscaled \
    --state="$STATE_DIR/tailscaled.state" \
    --socket="$RUN_DIR/tailscaled.sock" \
    --port=41641 \
    $TUN_ARG \
    $EXTRA_ARGS
