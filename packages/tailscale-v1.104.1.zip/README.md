# Tailscale for RosetteOS

Tailscale makes creating software-defined networks easy. Connect your 3D printer securely from anywhere in the world without port forwarding.

## Quick Start

### Option 1: Via Mainsail / Fluidd G-Code Macros
In the console:
- `TAILSCALE_UP AUTHKEY=<your-auth-key>` (connect using a reusable or pre-authenticated key from the Tailscale admin console)
- `TAILSCALE_STATUS` (view connection status)
- `TAILSCALE_IP` (display your printer's Tailscale IPv4 address)
- `TAILSCALE_DOWN` (disconnect)

### Option 2: Via SSH Command Line
From the terminal, `tailscale` is available in standard PATH:
```sh
tailscale up
tailscale status
tailscale ip -4
```
