#!/bin/sh
# RosetteOS Klipper-Backup v1 config converter (POSIX sh compatible)
# Note: script.sh automatically handles both v1 and v2 config formats via Python parser.
exit 0
