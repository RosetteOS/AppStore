#!/bin/sh
# RosetteOS Klipper-Backup file watcher (POSIX sh compatible)

SCRIPT_DIR=$(cd "$(dirname "$0")/.." && pwd -P)
exec /bin/sh "$SCRIPT_DIR/klipper-backup-service.sh" "$@"
