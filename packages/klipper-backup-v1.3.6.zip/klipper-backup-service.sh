#!/bin/sh
# RosetteOS Klipper-Backup automated background service
# Watches for configuration changes and performs automated GitHub backups

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
BACKUP_SCRIPT="$SCRIPT_DIR/script.sh"
STAMP_FILE="/var/run/klipper-backup.stamp"

# Config directory to watch
CONFIG_DIR="/usr/data/printer_data/config"
[ -d "$CONFIG_DIR" ] || CONFIG_DIR="/opt/printer_data/config"
[ -d "$CONFIG_DIR" ] || CONFIG_DIR="$HOME/printer_data/config"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Klipper-Backup service started."

# On service initialization (app install or startup), seed klipper-backup.env template if missing
TEMPLATE_SRC="$SCRIPT_DIR/klipper-backup.env"
[ -f "$TEMPLATE_SRC" ] || TEMPLATE_SRC="$SCRIPT_DIR/.env.example"

for target_dir in "/usr/data/printer_data/config" "/opt/printer_data/config" "$CONFIG_DIR"; do
    if [ -d "$target_dir" ] && [ ! -f "$target_dir/klipper-backup.env" ]; then
        if [ -f "$TEMPLATE_SRC" ]; then
            cp "$TEMPLATE_SRC" "$target_dir/klipper-backup.env"
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] Created template configuration at $target_dir/klipper-backup.env"
        fi
        break
    fi
done

check_credentials() {
    ENV_FILE=""
    if [ -f "/usr/data/printer_data/config/klipper-backup.env" ]; then
        ENV_FILE="/usr/data/printer_data/config/klipper-backup.env"
    elif [ -f "/opt/printer_data/config/klipper-backup.env" ]; then
        ENV_FILE="/opt/printer_data/config/klipper-backup.env"
    elif [ -f "$CONFIG_DIR/klipper-backup.env" ]; then
        ENV_FILE="$CONFIG_DIR/klipper-backup.env"
    elif [ -f "$SCRIPT_DIR/.env" ]; then
        ENV_FILE="$SCRIPT_DIR/.env"
    fi

    [ -n "$ENV_FILE" ] || return 1

    TOKEN=$(grep -E "^github_token=" "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d ' "\r\n')
    REPO=$(grep -E "^github_repository=" "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d ' "\r\n')

    [ -n "$TOKEN" ] && [ "$TOKEN" != "ghp_xxxxxxxxxxxxxxxx" ] && [ -n "$REPO" ] && [ "$REPO" != "REPOSITORY" ]
}

wait_for_network() {
    for i in $(seq 1 30); do
        if curl -fsS -m 3 https://api.github.com >/dev/null 2>&1 || ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
            return 0
        fi
        sleep 2
    done
    return 1
}

is_printing() {
    STATE=$(curl -fsS -m 2 http://127.0.0.1:7125/printer/objects/query?print_stats 2>/dev/null | \
        grep -o '"state": *"[^"]*"' | cut -d'"' -f4)
    [ "$STATE" = "printing" ] || [ "$STATE" = "paused" ]
}

# Wait until credentials are provided before performing automated backups
while ! check_credentials; do
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Waiting for GitHub credentials in $CONFIG_DIR/klipper-backup.env..."
    sleep 30
done

# Perform initial backup on service startup
if wait_for_network && ! is_printing; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Performing startup backup..."
    /bin/bash "$BACKUP_SCRIPT" -c "Backup on startup - $(date '+%Y-%m-%d %H:%M:%S')" 2>&1 || true
fi

touch "$STAMP_FILE"

# Watch loop
while true; do
    sleep 30

    if ! check_credentials; then
        sleep 30
        continue
    fi

    CHANGED=$(find "$CONFIG_DIR" -type f -newer "$STAMP_FILE" \
        ! -name "*.swp" ! -name "*.tmp" ! -name "*.bak" ! -name "*.bkp" \
        ! -name "*.log" ! -name "klipper-backup.env" ! -name ".env" \
        ! -path "*/.git/*" 2>/dev/null | head -n 5)

    if [ -n "$CHANGED" ]; then
        sleep 15

        if is_printing; then
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] Changes detected but printer is active; postponing backup."
            continue
        fi

        FIRST_NAME=$(basename $(echo "$CHANGED" | head -n 1))
        COUNT=$(echo "$CHANGED" | wc -l)
        if [ "$COUNT" -gt 1 ]; then
            MSG="Auto backup: $FIRST_NAME and other files modified - $(date '+%Y-%m-%d %H:%M:%S')"
        else
            MSG="Auto backup: $FIRST_NAME modified - $(date '+%Y-%m-%d %H:%M:%S')"
        fi

        echo "[$(date '+%Y-%m-%d %H:%M:%S')] $MSG"
        touch "$STAMP_FILE"
        /bin/bash "$BACKUP_SCRIPT" -c "$MSG" 2>&1 || true
        touch "$STAMP_FILE"
    fi
done
