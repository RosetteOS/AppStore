#!/bin/sh
# RosetteOS Klipper-Backup execution script (POSIX / BusyBox ash compatible)
# Repository: https://github.com/Staubgeborener/klipper-backup

# Set parent directory path
parent_path=$(cd "$(dirname "$0")" && pwd -P)

# Locate environment configuration:
# 1. /usr/data/printer_data/config/klipper-backup.env (user editable in Mainsail/Fluidd)
# 2. /opt/printer_data/config/klipper-backup.env
# 3. $parent_path/.env
# 4. $HOME/klipper-backup/.env
# 5. /usr/data/rosetteos/apps/klipper-backup/.env
env_file=""
if [ -f "/usr/data/printer_data/config/klipper-backup.env" ]; then
    env_file="/usr/data/printer_data/config/klipper-backup.env"
elif [ -f "/opt/printer_data/config/klipper-backup.env" ]; then
    env_file="/opt/printer_data/config/klipper-backup.env"
elif [ -f "$parent_path/.env" ]; then
    env_file="$parent_path/.env"
elif [ -n "$HOME" ] && [ -f "$HOME/klipper-backup/.env" ]; then
    env_file="$HOME/klipper-backup/.env"
elif [ -f "/usr/data/rosetteos/apps/klipper-backup/.env" ]; then
    env_file="/usr/data/rosetteos/apps/klipper-backup/.env"
fi

if [ -z "$env_file" ] || [ ! -f "$env_file" ]; then
    # Automatically initialize template in /usr/data/printer_data/config/klipper-backup.env or /opt/printer_data/config/klipper-backup.env
    TEMPLATE_SRC="$parent_path/klipper-backup.env"
    [ -f "$TEMPLATE_SRC" ] || TEMPLATE_SRC="$parent_path/.env.example"

    for target_dir in "/usr/data/printer_data/config" "/opt/printer_data/config"; do
        if [ -d "$target_dir" ]; then
            env_file="$target_dir/klipper-backup.env"
            cp "$TEMPLATE_SRC" "$env_file" 2>/dev/null || true
            echo "Created template configuration at $env_file"
            echo "Please edit $env_file with your GitHub credentials before backing up."
            exit 1
        fi
    done

    if [ -f "$TEMPLATE_SRC" ]; then
        env_file="$parent_path/.env"
        cp "$TEMPLATE_SRC" "$env_file"
        echo "Created template configuration at $env_file"
        echo "Please edit $env_file with your GitHub credentials before backing up."
        exit 1
    else
        echo "Error: Klipper-Backup configuration file (.env) not found."
        exit 1
    fi
fi

# Parse klipper-backup.env safely (supports both scalar variables and bash-style array syntax)
eval "$(python3 - "$env_file" << 'PYEOF'
import sys, re, shlex

env_path = sys.argv[1]
try:
    with open(env_path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()
except Exception:
    sys.exit(0)

# Join line continuations
content = re.sub(r'\\\r?\n', ' ', content)

scalars = {}
arrays = {}

for raw_line in content.splitlines():
    line = raw_line.strip()
    if not line or line.startswith('#'):
        continue
    # Match array assignment: name=( ... )
    m_arr = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\((.*)\)\s*$', line)
    if m_arr:
        name, inner = m_arr.group(1), m_arr.group(2)
        try:
            items = shlex.split(inner, comments=True)
        except Exception:
            items = [x.strip('"\'') for x in inner.split() if x.strip('"\'')]
        arrays[name] = items
        continue

    # Match scalar assignment: name=value
    m_scalar = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$', line)
    if m_scalar:
        name, val_part = m_scalar.group(1), m_scalar.group(2).strip()
        try:
            tokens = shlex.split(val_part, comments=True)
            val = tokens[0] if tokens else ""
        except Exception:
            val = val_part.strip('"\'')
        scalars[name] = val

# Legacy v1 path_* fallback if backupPaths not explicitly set
if "backupPaths" not in arrays:
    v1_paths = [v for k, v in scalars.items() if k.startswith("path_") and v]
    if v1_paths:
        arrays["backupPaths"] = v1_paths

for k, v in scalars.items():
    print(f"{k}={shlex.quote(v)}")

for k, items in arrays.items():
    joined = "\n".join(items)
    print(f"{k}_LIST={shlex.quote(joined)}")
PYEOF
)"

. "$parent_path/utils/utils.func"

# Default parameters
branch_name=${branch_name:-"main"}
allow_empty_commits=${allow_empty_commits:-true}
use_filenames_as_commit_msg=${use_filenames_as_commit_msg:-false}
git_protocol=${git_protocol:-"https"}
git_host=${git_host:-"github.com"}
ssh_user=${ssh_user:-"git"}
commit_message_used=${commit_message_used:-false}
debug_output=${debug_output:-false}

if [ -z "$backupPaths_LIST" ]; then
    backupPaths_LIST="printer_data/config/*
printer_profiles/*"
fi

if [ -z "$exclude_LIST" ]; then
    exclude_LIST="*.swp
*.tmp
printer-[0-9]*_[0-9]*.cfg
*.bak
*.bkp
*.csv
*.zip
klipper-backup.env
.env
ShakeTune_results"
fi

# Set backup storage paths
backup_folder=${backup_folder:-"config_backup"}
if [ -z "$backup_path" ]; then
    if [ -d "/usr/data/rosetteos" ]; then
        backup_path="/usr/data/rosetteos/backup/config_backup"
    elif [ -n "$HOME" ]; then
        backup_path="$HOME/$backup_folder"
    else
        backup_path="/root/$backup_folder"
    fi
fi

# Parse CLI arguments
args="$*"
while [ $# -gt 0 ]; do
    case "$1" in
        -h|--help)
            show_help
            exit 0
            ;;
        -f|--fix)
            fix
            shift
            ;;
        -c|--commit_message)
            if [ -z "$2" ] || [ "${2#-}" != "$2" ]; then
                printf "\r\033[K%bError: commit message expected after %s%b\n" "$R" "$1" "$NC" >&2
                exit 1
            else
                commit_message="$2"
                commit_message_used=true
                shift 2
            fi
            ;;
        -d|--debug)
            debug_output=true
            shift
            ;;
        *)
            printf "\r\033[K%bUnknown option: %s%b\n" "$R" "$1" "$NC"
            show_help
            exit 1
            ;;
    esac
done

# Verify GitHub credentials before proceeding
case "$github_token" in
    ""|ghp_xxxxxxxxxxxxxxxx*)
        echo "Error: Klipper-Backup is not configured yet."
        echo "Please set your github_token, github_username, and github_repository in: $env_file"
        exit 1
        ;;
esac
case "$github_repository" in
    ""|REPOSITORY*)
        echo "Error: Klipper-Backup is not configured yet."
        echo "Please set your github_token, github_username, and github_repository in: $env_file"
        exit 1
        ;;
esac

if [ -t 1 ]; then
    loading_wheel "${Y}●${NC} Checking for installed dependencies" &
    loading_pid=$!
    check_dependencies "curl" "rsync"
    kill "$loading_pid" 2>/dev/null || true
    printf "\r\033[K%b●%b Checking for installed dependencies %bDone!%b\n\n" "$G" "$NC" "$G" "$NC"
else
    check_dependencies "curl" "rsync"
fi

if [ "$git_protocol" = "ssh" ]; then
    full_git_url="${git_protocol}://${ssh_user}@${git_host}/${github_username}/${github_repository}.git"
else
    full_git_url="${git_protocol}://${github_token}@${git_host}/${github_username}/${github_repository}.git"
fi

if [ "$debug_output" = "true" ]; then
    begin_debug_line
    echo "Command: $0 $args"
    end_debug_line

    begin_debug_line
    while IFS= read -r line; do
        case "$line" in
            github_token=*) echo "github_token=**********" ;;
            commit_email=*) echo "commit_email=**********" ;;
            *) echo "$line" ;;
        esac
    done < "$env_file"
    end_debug_line

    if [ "$git_host" = "github.com" ]; then
        begin_debug_line
        if curl -fsS "https://api.github.com/repos/${github_username}/${github_repository}" >/dev/null 2>&1; then
            echo "The GitHub repo ${github_username}/${github_repository} exists (public)"
        else
            echo "Notice: GitHub repo ${github_username}/${github_repository} not public or requires auth"
        fi
        end_debug_line
    fi
fi

# Check if backup folder exists, create one if it does not
if [ ! -d "$backup_path" ]; then
    mkdir -p "$backup_path"
fi

cd "$backup_path" || exit 1

# Check if .git exists else init git repo
if [ ! -d ".git" ]; then
    mkdir -p .git
    cat >>.git/config <<EOF
[init]
    defaultBranch = $branch_name
EOF
    git init
elif [ "$(git symbolic-ref --short -q HEAD 2>/dev/null)" != "$branch_name" ]; then
    echo "Branch: $branch_name in .env does not match the currently checked out branch of: $(git symbolic-ref --short -q HEAD 2>/dev/null)."
    if git show-ref --quiet --verify "refs/heads/$branch_name"; then
        git checkout "$branch_name" >/dev/null 2>&1
    else
        git checkout -b "$branch_name" >/dev/null 2>&1
    fi
fi

# Configure committer identity
if [ -n "$commit_username" ]; then
    git config user.name "$commit_username"
else
    who=$(whoami 2>/dev/null || echo "root")
    git config user.name "$who"
    sed -i "s/^commit_username=.*/commit_username=\"$who\"/" "$env_file" 2>/dev/null || true
fi

if [ -n "$commit_email" ]; then
    git config user.email "$commit_email"
else
    host=$(hostname 2>/dev/null || echo "rosetteos")
    who=$(whoami 2>/dev/null || echo "root")
    unique_id=$(date +%s%N 2>/dev/null | md5sum | head -c 7)
    [ -z "$unique_id" ] && unique_id="0000000"
    user_email="${who}@${host}-${unique_id}"
    git config user.email "$user_email"
    sed -i "s/^commit_email=.*/commit_email=\"$user_email\"/" "$env_file" 2>/dev/null || true
fi

# Check if remote origin already exists and create/update if needed
if [ -z "$(git remote get-url origin 2>/dev/null)" ]; then
    git remote add origin "$full_git_url"
elif [ "$full_git_url" != "$(git remote get-url origin 2>/dev/null)" ]; then
    git remote set-url origin "$full_git_url"
fi

# Check if branch exists on remote and pull any new changes
if git ls-remote --exit-code --heads origin "$branch_name" >/dev/null 2>&1; then
    git pull origin "$branch_name" 2>/dev/null || true
    find "$backup_path" -maxdepth 1 -mindepth 1 ! -name '.git' ! -name 'README.md' ! -name '.gitmodules' -exec rm -rf {} \;
fi

# Copy files defined in backupPaths
printf '%s\n' "$backupPaths_LIST" | while IFS= read -r path; do
    [ -n "$path" ] || continue
    case "$path" in
        /*)
            fullPath="$path"
            baseDir="/"
            ;;
        *)
            if [ -e "/usr/data/rosetteos/$path" ] || [ -d "/usr/data/rosetteos/$(dirname "$path")" ]; then
                fullPath="/usr/data/rosetteos/$path"
                baseDir="/usr/data/rosetteos"
            elif [ -e "/usr/data/$path" ] || [ -d "/usr/data/$(dirname "$path")" ]; then
                fullPath="/usr/data/$path"
                baseDir="/usr/data"
            elif [ -e "/opt/$path" ] || [ -d "/opt/$(dirname "$path")" ]; then
                fullPath="/opt/$path"
                baseDir="/opt"
            elif [ -n "$HOME" ] && { [ -e "$HOME/$path" ] || [ -d "$HOME/$(dirname "$path")" ]; }; then
                fullPath="$HOME/$path"
                baseDir="$HOME"
            else
                fullPath="/usr/data/rosetteos/$path"
                baseDir="/usr/data/rosetteos"
            fi
            ;;
    esac

    cd "$baseDir" || continue
    # Expand globs including dotfiles safely via Python
    python3 - "$baseDir" "$fullPath" << 'PYGLOB' | while IFS= read -r relPath; do
import sys, os, glob

base_dir = sys.argv[1]
pattern = sys.argv[2]

matches = set(glob.glob(pattern))
# Also include hidden files when pattern ends with /*
if pattern.endswith("/*"):
    matches.update(glob.glob(pattern[:-2] + "/.*"))

for m in sorted(matches):
    base = os.path.basename(m)
    if base in (".", ".."):
        continue
    if os.path.islink(m):
        print("SYMLINK:" + m)
    elif os.path.exists(m):
        rel = os.path.relpath(m, base_dir)
        print("FILE:" + rel)
PYGLOB
        case "$relPath" in
            SYMLINK:*)
                echo "Skipping symbolic link: ${relPath#SYMLINK:}"
                ;;
            FILE:*)
                rpath="${relPath#FILE:}"
                rsync -Rr --filter "- /.git/" --filter "- /.github/" "$rpath" "$backup_path"
                ;;
        esac
    done
done

cd "$backup_path" || exit 1
cp "$parent_path/.gitignore" "$backup_path/.gitignore" 2>/dev/null || true

printf '%s\n' "$exclude_LIST" | while IFS= read -r i; do
    [ -n "$i" ] || continue
    if [ -f "$backup_path/.gitignore" ]; then
        echo "$i" >>"$backup_path/.gitignore"
    fi
done

if [ "$commit_message_used" != "true" ]; then
    commit_message="New backup from $(date +"%Y-%m-%d %H:%M:%S")"
fi

if [ ! -f "README.md" ]; then
    printf "# Klipper-Backup 💾 \nKlipper backup repository for automated GitHub backups \n\nGenerated by [Klipper-Backup](https://github.com/Staubgeborener/klipper-backup) on [RosetteOS](https://github.com/RosetteOS).\n" >"$backup_path/README.md"
fi

if [ "$use_filenames_as_commit_msg" = "true" ]; then
    commit_message=$(git diff --name-only "$branch_name" 2>/dev/null | xargs -n 1 basename 2>/dev/null | tr '\n' ' ')
    [ -z "$commit_message" ] && commit_message="Backup $(date +"%Y-%m-%d %H:%M:%S")"
fi

git rm -r --cached . >/dev/null 2>&1 || true
git add .

git commit -m "$commit_message" 2>/dev/null || true

if [ "$allow_empty_commits" = "true" ]; then
    upstream_branch=$(git rev-parse --abbrev-ref '@{u}' 2>/dev/null | sed 's/\// /g')
    if [ -n "$upstream_branch" ]; then
        local_rev=$(git rev-parse HEAD 2>/dev/null)
        remote_rev=$(git ls-remote $upstream_branch 2>/dev/null | cut -f1)
        if [ -n "$local_rev" ] && [ "$local_rev" = "$remote_rev" ]; then
            git commit --allow-empty -m "$commit_message - No new changes pushed"
        fi
    fi
fi

echo "Pushing configuration backup to GitHub ($branch_name)..."
git push -u origin "$branch_name"

find "$backup_path" -maxdepth 1 -mindepth 1 ! -name '.git' ! -name 'README.md' ! -name '.gitmodules' -exec rm -rf {} \;
echo "Backup complete!"
