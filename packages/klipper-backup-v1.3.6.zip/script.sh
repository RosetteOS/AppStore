#!/usr/bin/env bash

# set dotglob so that bash treats hidden files/folders starting with . correctly when copying them (ex. .themes from mainsail)
shopt -s dotglob

# Set parent directory path
parent_path=$(
    cd "$(dirname "${BASH_SOURCE[0]}")"
    pwd -P
)

# Locate environment configuration:
# 1. /usr/data/printer_data/config/klipper-backup.env (user editable in Mainsail/Fluidd)
# 2. /opt/printer_data/config/klipper-backup.env
# 3. $parent_path/.env
# 4. $HOME/klipper-backup/.env
# 5. /usr/data/rosetteos/apps/klipper-backup/.env
env_file=""
if [ -f "/usr/data/printer_data/config/klipper-backup.env" ]; then
    env_file="/usr/data/printer_data/config/klipper-backup.env"
elif [ -f "/opt/printer_data/config/klipper-backup.env" ]; then
    env_file="/opt/printer_data/config/klipper-backup.env"
elif [ -f "$parent_path/.env" ]; then
    env_file="$parent_path/.env"
elif [ -f "$HOME/klipper-backup/.env" ]; then
    env_file="$HOME/klipper-backup/.env"
elif [ -f "/usr/data/rosetteos/apps/klipper-backup/.env" ]; then
    env_file="/usr/data/rosetteos/apps/klipper-backup/.env"
fi

if [ -n "$env_file" ] && [ -f "$env_file" ]; then
    source "$env_file"
else
    # Automatically initialize template in /usr/data/printer_data/config/klipper-backup.env or /opt/printer_data/config/klipper-backup.env
    TEMPLATE_SRC="$parent_path/klipper-backup.env"
    [ -f "$TEMPLATE_SRC" ] || TEMPLATE_SRC="$parent_path/.env.example"

    for target_dir in "/usr/data/printer_data/config" "/opt/printer_data/config"; do
        if [ -d "$target_dir" ]; then
            env_file="$target_dir/klipper-backup.env"
            cp "$TEMPLATE_SRC" "$env_file" 2>/dev/null || true
            echo "Created template configuration at $env_file"
            echo "Please edit $env_file with your GitHub credentials before backing up."
            exit 1
        fi
    done

    if [ -f "$TEMPLATE_SRC" ]; then
        env_file="$parent_path/.env"
        cp "$TEMPLATE_SRC" "$env_file"
        echo "Created template configuration at $env_file"
        echo "Please edit $env_file with your GitHub credentials before backing up."
        exit 1
    else
        echo "Error: Klipper-Backup configuration file (.env) not found."
        exit 1
    fi
fi

source "$parent_path"/utils/utils.func

# Verify GitHub credentials before proceeding
if [[ "$github_token" == "ghp_xxxxxxxxxxxxxxxx"* ]] || [[ -z "$github_token" ]] || [[ "$github_repository" == "REPOSITORY"* ]] || [[ -z "$github_repository" ]]; then
    echo "Error: Klipper-Backup is not configured yet."
    echo "Please set your github_token, github_username, and github_repository in: $env_file"
    exit 1
fi

if [ -t 1 ]; then
    loading_wheel "${Y}●${NC} Checking for installed dependencies" &
    loading_pid=$!
    check_dependencies "curl" "rsync"
    kill $loading_pid 2>/dev/null || true
    echo -e "\r\033[K${G}●${NC} Checking for installed dependencies ${G}Done!${NC}\n"
else
    check_dependencies "curl" "rsync"
fi

# Set backup storage paths
backup_folder=${backup_folder:-"config_backup"}
if [ -z "$backup_path" ]; then
    if [ -d "/usr/data/rosetteos" ]; then
        backup_path="/usr/data/rosetteos/backup/config_backup"
    elif [ -n "$HOME" ]; then
        backup_path="$HOME/$backup_folder"
    else
        backup_path="/root/$backup_folder"
    fi
fi

allow_empty_commits=${allow_empty_commits:-true}
use_filenames_as_commit_msg=${use_filenames_as_commit_msg:-false}
git_protocol=${git_protocol:-"https"}
git_host=${git_host:-"github.com"}
ssh_user=${ssh_user:-"git"}

if [[ $git_protocol == "ssh" ]]; then
    full_git_url=$git_protocol"://"$ssh_user"@"$git_host"/"$github_username"/"$github_repository".git"
else
    full_git_url=$git_protocol"://"$github_token"@"$git_host"/"$github_username"/"$github_repository".git"
fi
exclude=${exclude:-"*.swp" "*.tmp" "printer-[0-9]*_[0-9]*.cfg" "*.bak" "*.bkp" "*.csv" "*.zip" "klipper-backup.env" ".env"}

# Required for checking the use of the commit_message and debug parameter
commit_message_used=${commit_message_used:-false}
debug_output=${debug_output:-false}
args="$@"

# Check parameters
while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help)
      show_help
      exit 0
      ;;
    -f|--fix)
      fix
      shift
      ;;
    -c|--commit_message)
      if [[ -z "$2" || "$2" =~ ^- ]]; then
          echo -e "\r\033[K${R}Error: commit message expected after $1${NC}" >&2
          exit 1
      else
          commit_message="$2"
          commit_message_used=true
          shift 2
      fi
      ;;
    -d|--debug)
      debug_output=true
      shift
      ;;
    *)
      echo -e "\r\033[K${R}Unknown option: $1${NC}"
      show_help
      exit 1
      ;;
  esac
done

# Check for updates if running from a git clone
if [ -d "$parent_path/.git" ]; then
    upstream_ref=$(git -C "$parent_path" rev-parse --abbrev-ref @{u} 2>/dev/null | sed 's/\// /g')
    if [ -n "$upstream_ref" ]; then
        remote_head=$(git -C "$parent_path" ls-remote $upstream_ref 2>/dev/null | cut -f1)
        local_head=$(git -C "$parent_path" rev-parse HEAD 2>/dev/null)
        if [ "$local_head" = "$remote_head" ]; then
            echo -e "Klipper-Backup is up to date\n"
        else
            echo -e "${Y}●${NC} Update for Klipper-Backup ${Y}Available!${NC}\n"
        fi
    fi
fi

# Check if .env is v1 version
if [[ ! -v backupPaths ]]; then
    echo ".env file is not using version 2 config, upgrading to V2"
    if bash "$parent_path/utils/v1convert.sh"; then
        echo "Upgrade complete restarting script.sh"
        sleep 2.5
        exec "$parent_path/script.sh" "$args"
    fi
fi

if [ "$debug_output" = true ]; then
    begin_debug_line
    if [[ "$SHELL" == */bash* ]]; then
        echo -e "Command: $0 $args"
    fi
    end_debug_line

    begin_debug_line
    shopt -s nocaseglob
    while IFS= read -r line; do
        if [[ $line == github_token=* ]]; then
            echo "github_token=**********"
        elif [[ $line == commit_email=* ]]; then
            echo "commit_email=**********"
        else
            echo "$line"
        fi
    done < "$env_file"
    shopt -u nocasematch
    end_debug_line

    if [[ $git_host == "github.com" ]]; then
        begin_debug_line
        if curl -fsS "https://api.github.com/repos/${github_username}/${github_repository}" >/dev/null 2>&1; then
            echo "The GitHub repo ${github_username}/${github_repository} exists (public)"
        else
            echo "Notice: GitHub repo ${github_username}/${github_repository} not public or requires auth"
        fi
        end_debug_line
    fi
fi

# Check if backup folder exists, create one if it does not
if [ ! -d "$backup_path" ]; then
    mkdir -p "$backup_path"
fi

cd "$backup_path"

# Check if .git exists else init git repo
if [ ! -d ".git" ]; then
    mkdir -p .git
    echo "[init]
    defaultBranch = $branch_name" >>.git/config
    git init
elif [[ $(git symbolic-ref --short -q HEAD 2>/dev/null) != "$branch_name" ]]; then
    echo -e "Branch: $branch_name in .env does not match the currently checked out branch of: $(git symbolic-ref --short -q HEAD 2>/dev/null)."
    if git show-ref --quiet --verify "refs/heads/$branch_name"; then
        git checkout "$branch_name" >/dev/null 2>&1
    else
        git checkout -b "$branch_name" >/dev/null 2>&1
    fi
fi

# Configure committer identity
if [[ "$commit_username" != "" ]]; then
    git config user.name "$commit_username"
else
    who=$(whoami 2>/dev/null || echo "root")
    git config user.name "$who"
    sed -i "s/^commit_username=.*/commit_username=\"$who\"/" "$env_file" 2>/dev/null || true
fi

if [[ "$commit_email" != "" ]]; then
    git config user.email "$commit_email"
else
    host=$(hostname 2>/dev/null || echo "rosetteos")
    who=$(whoami 2>/dev/null || echo "root")
    unique_id=$(date +%s%N 2>/dev/null | md5sum | head -c 7)
    [ -z "$unique_id" ] && unique_id="0000000"
    user_email="${who}@${host}-${unique_id}"
    git config user.email "$user_email"
    sed -i "s/^commit_email=.*/commit_email=\"$user_email\"/" "$env_file" 2>/dev/null || true
fi

# Check if remote origin already exists and create/update if needed
if [ -z "$(git remote get-url origin 2>/dev/null)" ]; then
    git remote add origin "$full_git_url"
elif [[ "$full_git_url" != $(git remote get-url origin 2>/dev/null) ]]; then
    git remote set-url origin "$full_git_url"
fi

# Check if branch exists on remote and pull any new changes
if git ls-remote --exit-code --heads origin "$branch_name" >/dev/null 2>&1; then
    git pull origin "$branch_name" 2>/dev/null || true
    find "$backup_path" -maxdepth 1 -mindepth 1 ! -name '.git' ! -name 'README.md' ! -name '.gitmodules' -exec rm -rf {} \;
fi

# Copy files defined in backupPaths
for path in "${backupPaths[@]}"; do
    if [[ "$path" == /* ]]; then
        fullPath="$path"
        baseDir="/"
    elif [[ -e "$HOME/$path" || -d "$HOME/$(dirname "$path")" ]]; then
        fullPath="$HOME/$path"
        baseDir="$HOME"
    elif [[ -e "/opt/$path" || -d "/opt/$(dirname "$path")" ]]; then
        fullPath="/opt/$path"
        baseDir="/opt"
    elif [[ -e "/usr/data/$path" || -d "/usr/data/$(dirname "$path")" ]]; then
        fullPath="/usr/data/$path"
        baseDir="/usr/data"
    else
        fullPath="$HOME/$path"
        baseDir="$HOME"
    fi

    shopt -s nullglob
    files=( $fullPath )
    shopt -u nullglob

    if [ ${#files[@]} -gt 0 ]; then
        cd "$baseDir"
        for file in "${files[@]}"; do
            if [ -h "$file" ]; then
                echo "Skipping symbolic link: $file"
            else
                relPath="${file#$baseDir/}"
                rsync -Rr --filter "- /.git/" --filter "- /.github/" "$relPath" "$backup_path"
            fi
        done
    fi
done

cd "$backup_path"
cp "$parent_path"/.gitignore "$backup_path/.gitignore" 2>/dev/null || true

for i in "${exclude[@]}"; do
    if [ -f "$backup_path/.gitignore" ]; then
        [[ $(tail -c1 "$backup_path/.gitignore" 2>/dev/null | wc -l) -eq 0 ]] && echo "" >>"$backup_path/.gitignore"
        echo "$i" >>"$backup_path/.gitignore"
    fi
done

if ! $commit_message_used; then
    commit_message="New backup from $(date +"%Y-%m-%d %H:%M:%S")"
fi

if ! [ -f "README.md" ]; then
    echo -e "# Klipper-Backup 💾 \nKlipper backup repository for automated GitHub backups \n\nGenerated by [Klipper-Backup](https://github.com/Staubgeborener/klipper-backup) on [RosetteOS](https://github.com/RosetteOS)." >"$backup_path/README.md"
fi

if $use_filenames_as_commit_msg; then
    commit_message=$(git diff --name-only "$branch_name" 2>/dev/null | xargs -n 1 basename 2>/dev/null | tr '\n' ' ')
    [ -z "$commit_message" ] && commit_message="Backup $(date +"%Y-%m-%d %H:%M:%S")"
fi

git rm -r --cached . >/dev/null 2>&1 || true
git add .

git commit -m "$commit_message" 2>/dev/null || true

if $allow_empty_commits && [[ $(git rev-parse HEAD 2>/dev/null) == $(git ls-remote $(git rev-parse --abbrev-ref @{u} 2>/dev/null | sed 's/\// /g') 2>/dev/null | cut -f1) ]]; then
    git commit --allow-empty -m "$commit_message - No new changes pushed"
fi

echo "Pushing configuration backup to GitHub ($branch_name)..."
git push -u origin "$branch_name"

find "$backup_path" -maxdepth 1 -mindepth 1 ! -name '.git' ! -name 'README.md' ! -name '.gitmodules' -exec rm -rf {} \;
echo "Backup complete!"
