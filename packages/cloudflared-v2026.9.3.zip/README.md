# Cloudflare Tunnel (`cloudflared`) for RosetteOS

Access Mainsail or Fluidd securely over HTTPS from anywhere without opening router ports or needing a kernel `tun` driver.

## Mode 1: Instant Quick Tunnel (Default, Zero Configuration)
Out of the box, `cloudflared` automatically starts a temporary Cloudflare Quick Tunnel (`https://<random-name>.trycloudflare.com`) forwarding to local port `80`.
- Run `CLOUDFLARED_STATUS` in the Mainsail/Fluidd console (or check `cloudflared.log`) to view your active `https://*.trycloudflare.com` URL.

## Mode 2: Persistent Cloudflare Zero Trust Tunnel (Custom Domain)
1. Create a tunnel in the [Cloudflare Zero Trust Dashboard](https://one.dash.cloudflare.com/) (**Networks → Tunnels**) and point a public hostname to `http://127.0.0.1:80`.
2. Copy your tunnel token (`eyJh...`) and run in the Mainsail/Fluidd console:
   ```
   CLOUDFLARED_SET_TOKEN TOKEN=eyJh...
   ```
   (Or set `TUNNEL_TOKEN="eyJh..."` in `cloudflared.env` in your config folder and restart the service).
