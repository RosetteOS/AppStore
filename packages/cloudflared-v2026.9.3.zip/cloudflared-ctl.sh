#!/bin/sh
# RosetteOS Cloudflare Tunnel helper for Klipper G-code macros & CLI

STATE_DIR="/usr/data/rosetteos/cloudflared"
LOG_FILE="$STATE_DIR/cloudflared.log"
DAEMON_LOG="/var/log/rosetteos-app-cloudflared.log"

ENV_FILE="/usr/data/printer_data/config/cloudflared.env"
if [ ! -d "/usr/data/printer_data/config" ] && [ -d "/opt/printer_data/config" ]; then
    ENV_FILE="/opt/printer_data/config/cloudflared.env"
fi

extract_quick_url() {
    for f in "$LOG_FILE" "$DAEMON_LOG"; do
        if [ -f "$f" ]; then
            url=$(grep -oE 'https://[a-zA-Z0-9-]+\.trycloudflare\.com' "$f" 2>/dev/null | tail -n 1)
            if [ -n "$url" ]; then
                echo "$url"
                return 0
            fi
        fi
    done
    return 1
}

show_status() {
    TUNNEL_TOKEN=""
    TUNNEL_URL="http://127.0.0.1:80"
    [ -f "$ENV_FILE" ] && . "$ENV_FILE"

    if pidof cloudflared >/dev/null 2>&1; then
        echo "Cloudflare Tunnel: RUNNING"
    else
        echo "Cloudflare Tunnel: STOPPED"
    fi

    if [ -n "$TUNNEL_TOKEN" ]; then
        echo "Mode: Named Zero Trust Tunnel (token configured in $ENV_FILE)"
    else
        echo "Mode: Quick Tunnel -> ${TUNNEL_URL:-http://127.0.0.1:80}"
        url=$(extract_quick_url)
        if [ -n "$url" ]; then
            echo "Public URL: $url"
        else
            echo "Public URL: (negotiating tunnel with Cloudflare edge, run CLOUDFLARED_STATUS again in a few seconds)"
        fi
    fi
}

case "$1" in
    status|"")
        show_status
        ;;
    set-token)
        token="$2"
        if [ -z "$token" ]; then
            echo "ERROR: Missing tunnel token"
            exit 1
        fi
        mkdir -p "$(dirname "$ENV_FILE")"
        cat > "$ENV_FILE" <<EOF
# RosetteOS Cloudflare Tunnel Configuration
TUNNEL_TOKEN="$token"
TUNNEL_URL="http://127.0.0.1:80"
TUNNEL_PROTOCOL="http2"
EXTRA_ARGS=""
EOF
        rosetteos-app service restart cloudflared >/dev/null 2>&1 || true
        sleep 2
        show_status
        ;;
    quick)
        port="${2:-80}"
        mkdir -p "$(dirname "$ENV_FILE")"
        cat > "$ENV_FILE" <<EOF
# RosetteOS Cloudflare Tunnel Configuration
TUNNEL_TOKEN=""
TUNNEL_URL="http://127.0.0.1:$port"
TUNNEL_PROTOCOL="http2"
EXTRA_ARGS=""
EOF
        rosetteos-app service restart cloudflared >/dev/null 2>&1 || true
        i=0
        while [ "$i" -lt 8 ]; do
            sleep 1
            if extract_quick_url >/dev/null 2>&1; then
                break
            fi
            i=$((i + 1))
        done
        show_status
        ;;
    restart)
        rosetteos-app service restart cloudflared >/dev/null 2>&1 || true
        sleep 2
        show_status
        ;;
    *)
        echo "Usage: $0 {status|set-token <token>|quick [port]|restart}"
        exit 1
        ;;
esac
