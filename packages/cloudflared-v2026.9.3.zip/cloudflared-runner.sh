#!/bin/sh
# RosetteOS Cloudflare Tunnel (cloudflared) daemon service runner

APP_DIR="/usr/data/rosetteos/apps/cloudflared"
STATE_DIR="/usr/data/rosetteos/cloudflared"
BIN_DIR="/usr/data/rosetteos/bin"
LOG_FILE="$STATE_DIR/cloudflared.log"

mkdir -p "$STATE_DIR"
mkdir -p "$BIN_DIR"

export HOME="$STATE_DIR"
export GOMEMLIMIT="24MiB"

# Ensure CLI symlink exists in user PATH
[ -e "$BIN_DIR/cloudflared" ] || ln -sf "$APP_DIR/cloudflared" "$BIN_DIR/cloudflared"

# Find or initialize cloudflared.env in printer_data/config
ENV_FILE=""
for d in "/usr/data/printer_data/config" "/opt/printer_data/config"; do
    if [ -d "$d" ]; then
        ENV_FILE="$d/cloudflared.env"
        break
    fi
done

if [ -n "$ENV_FILE" ] && [ ! -f "$ENV_FILE" ]; then
    cat > "$ENV_FILE" <<'EOF'
# RosetteOS Cloudflare Tunnel Configuration
# Leave TUNNEL_TOKEN empty to automatically start a free temporary Quick Tunnel (*.trycloudflare.com)
# Or paste your Cloudflare Zero Trust tunnel token below (or run CLOUDFLARED_SET_TOKEN TOKEN=...)
TUNNEL_TOKEN=""
TUNNEL_URL="http://127.0.0.1:80"
TUNNEL_PROTOCOL="http2"
EXTRA_ARGS=""
EOF
fi

TUNNEL_TOKEN=""
TUNNEL_URL="http://127.0.0.1:80"
TUNNEL_PROTOCOL="http2"
EXTRA_ARGS=""

if [ -n "$ENV_FILE" ] && [ -f "$ENV_FILE" ]; then
    . "$ENV_FILE"
fi

# Rotate previous log so CLOUDFLARED_STATUS always reads the current session's Quick Tunnel URL
rm -f "$LOG_FILE"

if [ -n "$TUNNEL_TOKEN" ]; then
    echo "Starting Cloudflare Named Zero Trust Tunnel..."
    exec "$APP_DIR/cloudflared" tunnel \
        --no-autoupdate \
        --protocol "${TUNNEL_PROTOCOL:-http2}" \
        --logfile "$LOG_FILE" \
        $EXTRA_ARGS \
        run --token "$TUNNEL_TOKEN"
else
    echo "Starting Cloudflare Quick Tunnel for ${TUNNEL_URL:-http://127.0.0.1:80}..."
    exec "$APP_DIR/cloudflared" tunnel \
        --no-autoupdate \
        --protocol "${TUNNEL_PROTOCOL:-http2}" \
        --logfile "$LOG_FILE" \
        $EXTRA_ARGS \
        --url "${TUNNEL_URL:-http://127.0.0.1:80}"
fi
