# OpenKE Remote Display VNC Server

Connect remotely to your printer display via:
- Native VNC Viewer: vnc://<printer-ip>:5900
- Web Browser (noVNC): http://<printer-ip>:5800
