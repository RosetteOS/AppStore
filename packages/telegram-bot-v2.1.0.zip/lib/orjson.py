"""Pure-Python compatibility shim for orjson on MIPS32el."""
import json as _json

JSONDecodeError = _json.JSONDecodeError
JSONEncodeError = TypeError

OPT_APPEND_NEWLINE = 1 << 0
OPT_INDENT_2 = 1 << 1
OPT_NAIVE_UTC = 1 << 2
OPT_NON_STR_KEYS = 1 << 3
OPT_OMIT_MICROSECONDS = 1 << 4
OPT_PASSTHROUGH_DATACLASS = 1 << 5
OPT_PASSTHROUGH_DATETIME = 1 << 6
OPT_PASSTHROUGH_SUBCLASS = 1 << 7
OPT_SERIALIZE_DATACLASS = 1 << 8
OPT_SERIALIZE_NUMPY = 1 << 9
OPT_SERIALIZE_UUID = 1 << 10
OPT_SORT_KEYS = 1 << 11
OPT_STRICT_INTEGER = 1 << 12
OPT_UTC_Z = 1 << 13


def loads(obj, *args, **kwargs):
    return _json.loads(obj)


def dumps(obj, default=None, option=None, *args, **kwargs):
    return _json.dumps(obj, default=default)
